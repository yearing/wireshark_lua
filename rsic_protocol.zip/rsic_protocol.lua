-- 插件名: RSIC Protocol
-- 版本: 2.0.1#20260813-2
-- 作者: 叶孟鹏
-- 描述: 广州18/22/11号线 及 广州10/12号线 RSIC协议，
--       依据 GZL18&22-S1-1903 V1.1 与 GZL10-S1-1903 V1.9 实现。
--       端口10020,10030,10090；双项目通过首选项切换。
--       字段展示格式: 编号.名称(Nbytes),字节序(X):值 [过滤器名]
--       枚举字段自动追加中文描述。
-- 更新时间: 2026-08-13
rsic_protocol = Proto("RSIC", "RSIC Protocol")

-- 首选项
local prefs = rsic_protocol.prefs
prefs.my_version = Pref.statictext("version:2.0.1#20260813-2",
                                   "2.0.1#20260813-2")
prefs.my_tcp_port = Pref.string("端口号(s):", "10020,10030,10090",
                                "RSIC默认端口")

local line_project_tab = {
    {1, "广州18&22&11号线 (GZL18)", 1},
    {2, "广州10&12号线 (GZL10)", 2}
}
prefs.my_line_project = Pref.enum("项目选择:",
                                  1,
                                  "线路号选择",
                                  line_project_tab,
                                  false)

-- ============================================
-- ProtoField 定义 (统一使用 rsic.* 过滤器前缀)
-- ============================================
local function sf(name, desc)
    return ProtoField.string("rsic." .. name, desc, base.ASCII)
end

local pf = {
    -- 底层帧头部
    data_head = ProtoField.uint16("rsic.data_head", "帧头", base.HEX),
    total     = ProtoField.uint8 ("rsic.total", "总帧数", base.DEC),
    index     = ProtoField.uint8 ("rsic.index", "当前帧", base.DEC),
    data_len  = ProtoField.uint16("rsic.data_len", "数据长度", base.DEC),
    dev_status= ProtoField.uint8 ("rsic.dev_status", "设备主备状态", base.DEC),
    data_tail = ProtoField.uint16("rsic.data_tail", "帧尾", base.HEX),
    data_type = ProtoField.uint16("rsic.data_type", "消息类型", base.DEC),

    -- 0x01 心跳
    heartbeat_state = sf("heartbeat_state", "心跳状态"),

    -- 0x02 列车信息
    train_count          = sf("train_count", "列车数量"),
    train_group_len      = sf("train_group_len", "车组号长度"),
    train_group          = sf("train_group", "车组号"),
    train_label_len      = sf("train_label_len", "车次号长度"),
    train_label          = sf("train_label", "车次号"),
    train_direction      = sf("train_direction", "方向"),
    central_station_id   = sf("central_station_id", "集中站编号"),
    front_partition_id   = sf("front_partition_id", "前端分区ID"),
    front_partition_offset = sf("front_partition_offset", "前端偏移量(cm)"),
    emergency_brake      = sf("emergency_brake", "紧急制动状态"),
    block_status         = sf("block_status", "阻塞标志"),
    sleep_wake_state     = sf("sleep_wake_state", "休眠唤醒状态"),
    work_info            = sf("work_info", "工况信息"),
    auto_drive_auth      = sf("auto_drive_auth", "全自动驾驶授权确认"),
    dep_request          = sf("dep_request", "发车请求"),
    cam_request          = sf("cam_request", "CAM模式请求状态"),
    clear_plat_id        = sf("clear_plat_id", "清客站台ID"),
    over_under_status    = sf("over_under_status", "欠/超标状态"),
    skip_mode            = sf("skip_mode", "跳跃模式"),
    fire_alarm           = sf("fire_alarm", "火灾报警状态"),
    drive_mode           = sf("drive_mode", "列车驾驶模式"),
    parking_accuracy     = sf("parking_accuracy", "停车精度(cm)"),
    train_speed          = sf("train_speed", "列车速度(cm/s)"),
    train_spare          = sf("train_spare", "预留"),

    -- 0x03 计划信息
    plat_count      = sf("plat_count", "站台数"),
    station_id      = sf("station_id", "车站编号"),
    platform_id     = sf("platform_id", "站台编号"),
    platform_train_count = sf("platform_train_count", "站台列车趟数"),
    stop_train_type = sf("stop_train_type", "停车类型"),
    plan_arrive_time= sf("plan_arrive_time", "计划到站时间"),
    plan_depart_time= sf("plan_depart_time", "计划离站时间"),
    dest_id         = sf("dest_id", "终到站"),
    current_status  = sf("current_status", "当前状态"),
    hold_train      = sf("hold_train", "是否扣车"),
    spare_1         = sf("spare_1", "预留1"),
    fast_train_flag = sf("fast_train_flag", "大站快车标志"),
    next_stop_id    = sf("next_stop_id", "下一停车站站码"),
    clear_flag      = sf("clear_flag", "清客标志"),
    spare_2         = sf("spare_2", "预留2"),

    -- 0x04 首末班信息
    first_group_len = sf("first_group_len", "首班车组号长度"),
    first_group     = sf("first_group", "首班车组号"),
    first_label_len = sf("first_label_len", "首班车次号长度"),
    first_label     = sf("first_label", "首班车次号"),
    first_stop_type = sf("first_stop_type", "首班停车类型"),
    first_arrive    = sf("first_arrive", "首班计划到站时间"),
    first_depart    = sf("first_depart", "首班计划离站时间"),
    first_dest      = sf("first_dest", "首班终到站"),
    last_group_len  = sf("last_group_len", "末班车组号长度"),
    last_group      = sf("last_group", "末班车组号"),
    last_label_len  = sf("last_label_len", "末班车次号长度"),
    last_label      = sf("last_label", "末班车次号"),
    last_stop_type  = sf("last_stop_type", "末班停车类型"),
    last_arrive     = sf("last_arrive", "末班计划到站时间"),
    last_depart     = sf("last_depart", "末班计划离站时间"),
    last_dest       = sf("last_dest", "末班终到站"),

    -- 0x05 车门隔离 / 0x06 站台门隔离
    psd_plat_id     = sf("psd_plat_id", "站台(股道)ID"),
    nid_psd_1       = sf("nid_psd_1", "1侧站台门ID"),
    psd_1_isolation = sf("psd_1_isolation", "1侧故障隔离要求"),
    psd_1_open      = sf("psd_1_open", "1侧站台门打开状态"),
    nid_psd_2       = sf("nid_psd_2", "2侧站台门ID"),
    psd_2_isolation = sf("psd_2_isolation", "2侧故障隔离要求"),
    psd_2_open      = sf("psd_2_open", "2侧站台门打开状态"),

    -- 0x07 站场表示
    rtu_status      = sf("rtu_status", "RTU状态"),
    station_count   = sf("station_count", "车站信息个数"),
    station_code    = sf("station_code", "站码"),
    yard_data_len   = sf("yard_data_len", "站场表示信息长"),
    device_type     = sf("device_type", "设备类型"),
    device_id       = sf("device_id", "设备编号"),
    sema_len        = sf("sema_len", "色码长度"),
    sema_code       = sf("sema_code", "色码"),

    -- 0x08 供电臂/供电分区
    power_count     = sf("power_count", "供电区段数目"),
    power_section_id= sf("power_section_id", "供电区段编号"),
    power_status    = sf("power_status", "供电区段状态"),

    -- 0x09 首末班申请
    firstlast_request = sf("firstlast_request", "首末班申请"),

    -- 0x10 场段出入段计划 (GZL10)
    schedule_date       = sf("schedule_date", "调度日"),
    drawing_no_len      = sf("drawing_no_len", "图号长度"),
    drawing_no          = sf("drawing_no", "图号"),
    depot_station_code  = sf("depot_station_code", "段/场站码"),
    service_group_count = sf("service_group_count", "服务号组数"),
    service_no_len      = sf("service_no_len", "服务号长度"),
    service_no          = sf("service_no", "服务号"),
    out_depot_code      = sf("out_depot_code", "出段/场站码"),
    out_train_label_len = sf("out_train_label_len", "出段/场车次号长度"),
    out_train_label     = sf("out_train_label", "出段/场车次号"),
    out_train_group_len = sf("out_train_group_len", "出段/场车组号长度"),
    out_train_group     = sf("out_train_group", "出段/场车组号"),
    departure_track_len = sf("departure_track_len", "段/场内出发股道名称长度"),
    departure_track     = sf("departure_track", "段/场内出发股道名称"),
    planned_departure   = sf("planned_departure", "段/场内计划出发时间"),
    actual_departure    = sf("actual_departure", "段/场内出发时间"),
    departure_mark      = sf("departure_mark", "段/场内报点标志"),
    transfer_rail_out_len = sf("transfer_rail_out_len", "出段/场转换轨名称长度"),
    transfer_rail_out     = sf("transfer_rail_out", "出段/场转换轨名称"),
    transfer_arr_plan     = sf("transfer_arr_plan", "出段/场转换轨计划到达时间"),
    transfer_arr_actual   = sf("transfer_arr_actual", "出段/场转换轨到达时间"),
    transfer_dep_plan     = sf("transfer_dep_plan", "出段/场转换轨计划出发时间"),
    transfer_dep_actual   = sf("transfer_dep_actual", "出段/场转换轨出发时间"),
    transfer_mark_out     = sf("transfer_mark_out", "出段/场转换轨报点标志"),
    mainline_code_out     = sf("mainline_code_out", "出段/场正线站码"),
    mainline_arrival_out  = sf("mainline_arrival_out", "出段/场正线到达时间"),
    destination_code_out  = sf("destination_code_out", "出段/场目的地码"),
    in_depot_code         = sf("in_depot_code", "入段/场车辆段站码"),
    in_train_label_len    = sf("in_train_label_len", "入段/场车次号长度"),
    in_train_label        = sf("in_train_label", "入段/场车次号"),
    in_train_group_len    = sf("in_train_group_len", "入段/场车组号长度"),
    in_train_group        = sf("in_train_group", "入段/场车组号"),
    arrival_track_len     = sf("arrival_track_len", "段/场内到达股道名称长度"),
    arrival_track         = sf("arrival_track", "段/场内到达股道名称"),
    planned_arrival       = sf("planned_arrival", "段/场内计划到达时间"),
    actual_arrival        = sf("actual_arrival", "段/场内到达时间"),
    arrival_mark          = sf("arrival_mark", "段/场内报点标志"),
    transfer_rail_in_len  = sf("transfer_rail_in_len", "入段/场转换轨名称长度"),
    transfer_rail_in      = sf("transfer_rail_in", "入段/场转换轨名称"),
    in_transfer_arr_plan  = sf("in_transfer_arr_plan", "入段/场转换轨计划到达时间"),
    in_transfer_arr_actual= sf("in_transfer_arr_actual", "入段/场转换轨到达时间"),
    in_transfer_dep_plan  = sf("in_transfer_dep_plan", "入段/场转换轨计划出发时间"),
    in_transfer_dep_actual= sf("in_transfer_dep_actual", "入段/场转换轨出发时间"),
    transfer_mark_in      = sf("transfer_mark_in", "入段/场转换轨报点标志"),
    mainline_code_in      = sf("mainline_code_in", "入段/场正线站码"),
    mainline_arrival_in   = sf("mainline_arrival_in", "入段/场正线到达时间"),
    destination_code_in   = sf("destination_code_in", "入段/场目的地码"),
    is_initial            = sf("is_initial", "是否是初始化生成"),
    initial_time          = sf("initial_time", "初始化时间"),
    is_wash               = sf("is_wash", "是否回段洗车"),
    spare_plan            = sf("spare_plan", "预留"),
    is_auto_wake          = sf("is_auto_wake", "是否自动唤醒"),
    wakeup_time           = sf("wakeup_time", "计划唤醒时间"),
    is_clean              = sf("is_clean", "是否回库清扫"),
    clean_start           = sf("clean_start", "清扫开始时间"),
    clean_end             = sf("clean_end", "清扫结束时间"),
    is_auto_sleep         = sf("is_auto_sleep", "是否自动休眠"),
    spare_plan2           = sf("spare_plan2", "预留2"),

    -- 0x11 车站火灾 (GZL10)
    fire_station_count = sf("fire_station_count", "车站数目"),
    fire_station_id    = sf("fire_station_id", "车站编号"),
    fire_station_status= sf("fire_station_status", "车站火灾状态"),

    -- 0x12 区间火灾 (GZL10)
    zone_fire_count    = sf("zone_fire_count", "区间数目"),
    zone_fire_id       = sf("zone_fire_id", "区间编号"),
    zone_fire_status   = sf("zone_fire_status", "区间火灾状态"),

    -- 0x13 区间水位告警 (GZL10)
    water_count        = sf("water_count", "轨面水位传感器数目"),
    water_sensor_id    = sf("water_sensor_id", "轨面水位传感器编号"),
    water_status       = sf("water_status", "轨面水位告警标志"),
}

rsic_protocol.fields = {}
for _, v in pairs(pf) do table.insert(rsic_protocol.fields, v) end

-- ============================================
-- 枚举中文描述表
-- ============================================
local enum_ha       = {[1]="主机",[2]="备机"}
local enum_dir      = {[1]="向右/上行",[2]="向左/下行"}
local enum_block    = {[0]="未阻塞",[1]="阻塞"}
local enum_stop     = {[0]="到站停车",[1]="到站不停车"}
local enum_pstatus  = {[0]="未进站",[1]="即将进站",[2]="到站停稳"}
local enum_hold     = {[0]="未扣车",[1]="扣车中"}
local enum_fast     = {[0]="普通车",[1]="大站快车"}
local enum_clear    = {[0]="不清客",[1]="清客"}
local enum_power    = {[0]="未知",[1]="供电中",[2]="未供电"}
local enum_fire     = {[0]="未知",[1]="有火灾",[2]="无火灾"}
local enum_zone_fire= {[0]="无火灾",[1]="有火灾"}
local enum_water    = {[0]="无告警",[1]="有告警"}
local enum_work     = {[0]="无工况",[1]="待命",[2]="场内运行",[3]="进入正线服务",
                       [4]="停止正线服务",[5]="清扫",[6]="洗车",[7]="检修"}
local enum_drive_gzl18 = {[0x55]="确认收到全自动驾驶授权",[0xAA]="确认收到禁止全自动驾驶命令",[0xFF]="无命令"}
local enum_dep_req     = {[0x55]="发车请求",[0xAA]="无发车请求"}
local enum_cam_req     = {[0x55]="申请进入蠕动模式",[0xFF]="默认值"}
local enum_overunder   = {[0x55]="过标/正值",[0xAA]="欠标/负值",[0xFF]="默认值"}
local enum_skip        = {[0x55]="跳跃中",[0xAA]="未跳跃"}
local enum_train_fire  = {[0x55]="烟火报警有效",[0xFF]="默认/无效"}
local enum_eb          = {[0x55]="无紧急制动",[0xAA]="紧急制动"}
local enum_drive_gzl10 = {[0x01]="AM模式",[0x02]="CM模式",[0x03]="RM模式",
                          [0x04]="EUM模式",[0x05]="FAM模式",[0x06]="CAM模式",
                          [0x07]="RM60模式",[0x08]="RRM模式",[0xFF]="默认值"}
local enum_first_stop  = {[0]="到开",[1]="通过"}
local enum_bool        = {[0]="无效/否",[1]="有效/是"}

-- 辅助函数：追加枚举描述
local function desc(v, t)
    local d = t and t[v]
    if d then return " | " .. d end
    return ""
end

-- 数据类型字符串（应用帧Type）
local dataTypeStr = {
    [1]  = "心跳信息",
    [2]  = "列车信息",
    [3]  = "计划信息",
    [4]  = "首末班信息",
    [5]  = "车门隔离状态信息",
    [6]  = "站台门隔离状态信息",
    [7]  = "站场表示信息",
    [8]  = "供电臂/供电分区信息",
    [9]  = "首末班申请",
    [16] = "场段出入段计划信息",
    [17] = "车站火灾信息",
    [18] = "区间火灾信息",
    [19] = "区间轨面水位告警信息",
}

local data_dis = Dissector.get("data")

-- ============================================
-- 工具函数
-- ============================================

-- 7字节时间: 年(2B LE) + 月日时分秒(各1B)
local function fmt_time7(buf, off)
    local year  = buf(off, 2):le_uint()
    local month = buf(off + 2, 1):le_uint()
    local day   = buf(off + 3, 1):le_uint()
    local hour  = buf(off + 4, 1):le_uint()
    local min   = buf(off + 5, 1):le_uint()
    local sec   = buf(off + 6, 1):le_uint()
    return string.format("%04d-%02d-%02d %02d:%02d:%02d", year, month, day, hour, min, sec)
end

-- 读取变长ASCII字符串: 先读1字节长度，再读内容
local function read_varstr(buf, off)
    local len = buf(off, 1):le_uint()
    local str = ""
    if len > 0 then str = buf(off + 1, len):string() end
    return len, str, off + 1 + len
end

-- ============================================
-- 各消息类型解析函数
-- 入参: buf(TVB), off(在重组后data域中的偏移), tree(SubTree)
-- 返回: 新的 offset（指向该消息数据域末尾）
-- ============================================

-- 0x01 心跳 (4字节固定 0xFFFFFFFF)
local function parse_01(buf, off, tree)
    tree:add(pf.heartbeat_state, buf(off + 2, 4)):set_text(
        "1.心跳状态[heartbeat_state](4bytes),字节序(2):0x" .. buf(off + 2, 4) .. " | 固定0xFFFFFFFF")
    return off + 6
end

-- 0x02 列车信息 (GZL18: 每列车约39+变长；GZL10: 每列车约54+变长)
local function parse_02(buf, off, tree, is_gzl10)
    tree:add(pf.train_count, buf(off + 2, 2)):set_text(
        "1.列车数量[train_count](2bytes),字节序(2):" .. buf(off + 2, 2):le_uint())
    local num = buf(off + 2, 2):le_uint()
    local o = off + 4
    for i = 1, num do
        local start_o = o
        local gl, gstr, o2 = read_varstr(buf, o)
        local ll, lstr, o3 = read_varstr(buf, o2)
        -- 固定尾部长度: GZL18=24(方向~火警), GZL10=39(+驾驶模式,停车精度,列车速度,预留10)
        local fixed_len = is_gzl10 and 39 or 24
        local total_rec = 1 + gl + 1 + ll + fixed_len
        local rel = o - off
        local t = tree:add(buf(o, total_rec), "列车:" .. i .. "(变长+固定" .. fixed_len .. "bytes),字节序(" .. rel .. ")")

        t:add(pf.train_group_len, buf(o, 1)):set_text("车组号长度[train_group_len](1bytes),字节序(" .. rel .. "):" .. gl)
        o = o + 1
        t:add(pf.train_group, buf(o, gl)):set_text("车组号[train_group](" .. gl .. "bytes),字节序(" .. (o-off) .. "):" .. gstr)
        o = o + gl
        t:add(pf.train_label_len, buf(o, 1)):set_text("车次号长度[train_label_len](1bytes),字节序(" .. (o-off) .. "):" .. ll)
        o = o + 1
        t:add(pf.train_label, buf(o, ll)):set_text("车次号[train_label](" .. ll .. "bytes),字节序(" .. (o-off) .. "):" .. lstr)
        o = o + ll

        local dir = buf(o, 1):le_uint()
        t:add(pf.train_direction, buf(o, 1)):set_text("方向[train_direction](1bytes),字节序(" .. (o-off) .. "):" .. dir .. desc(dir, enum_dir))
        o = o + 1
        t:add(pf.central_station_id, buf(o, 2)):set_text("集中站编号[central_station_id](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2
        t:add(pf.front_partition_id, buf(o, 2)):set_text("前端分区ID[front_partition_id](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2
        t:add(pf.front_partition_offset, buf(o, 4)):set_text("前端偏移量(cm)[front_partition_offset](4bytes),字节序(" .. (o-off) .. "):" .. buf(o,4):le_uint())
        o = o + 4

        local eb = buf(o, 1):le_uint()
        t:add(pf.emergency_brake, buf(o, 1)):set_text("紧急制动状态[emergency_brake](1bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%02X", eb) .. desc(eb, enum_eb))
        o = o + 1
        local blk = buf(o, 1):le_uint()
        t:add(pf.block_status, buf(o, 1)):set_text("阻塞标志[block_status](1bytes),字节序(" .. (o-off) .. "):" .. blk .. desc(blk, enum_block))
        o = o + 1
        local sw = buf(o, 2):le_uint()
        t:add(pf.sleep_wake_state, buf(o, 2)):set_text("休眠唤醒状态[sleep_wake_state](2bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%04X", sw))
        o = o + 2
        local wk = buf(o, 1):le_uint()
        t:add(pf.work_info, buf(o, 1)):set_text("工况信息[work_info](1bytes),字节序(" .. (o-off) .. "):" .. wk .. desc(wk, enum_work))
        o = o + 1

        local ad = buf(o, 1):le_uint()
        local ad_desc = is_gzl10 and " | 预留" or desc(ad, enum_drive_gzl18)
        t:add(pf.auto_drive_auth, buf(o, 1)):set_text("全自动驾驶授权确认[auto_drive_auth](1bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%02X", ad) .. ad_desc)
        o = o + 1
        local dr = buf(o, 1):le_uint()
        local dr_desc = is_gzl10 and " | 预留" or desc(dr, enum_dep_req)
        t:add(pf.dep_request, buf(o, 1)):set_text("发车请求[dep_request](1bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%02X", dr) .. dr_desc)
        o = o + 1
        local cr = buf(o, 1):le_uint()
        local cr_desc = is_gzl10 and " | 预留" or desc(cr, enum_cam_req)
        t:add(pf.cam_request, buf(o, 1)):set_text("CAM模式请求状态[cam_request](1bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%02X", cr) .. cr_desc)
        o = o + 1

        t:add(pf.clear_plat_id, buf(o, 4)):set_text("清客站台ID[clear_plat_id](4bytes),字节序(" .. (o-off) .. "):" .. buf(o,4):le_uint())
        o = o + 4
        local ou = buf(o, 1):le_uint()
        t:add(pf.over_under_status, buf(o, 1)):set_text("欠/超标状态[over_under_status](1bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%02X", ou) .. desc(ou, enum_overunder))
        o = o + 1
        local sk = buf(o, 1):le_uint()
        t:add(pf.skip_mode, buf(o, 1)):set_text("跳跃模式[skip_mode](1bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%02X", sk) .. desc(sk, enum_skip))
        o = o + 1
        local fa = buf(o, 1):le_uint()
        t:add(pf.fire_alarm, buf(o, 1)):set_text("火灾报警状态[fire_alarm](1bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%02X", fa) .. desc(fa, enum_train_fire))
        o = o + 1

        if is_gzl10 then
            local dm = buf(o, 1):le_uint()
            t:add(pf.drive_mode, buf(o, 1)):set_text("列车驾驶模式[drive_mode](1bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%02X", dm) .. desc(dm, enum_drive_gzl10))
            o = o + 1
            t:add(pf.parking_accuracy, buf(o, 2)):set_text("停车精度(cm)[parking_accuracy](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
            o = o + 2
            t:add(pf.train_speed, buf(o, 2)):set_text("列车速度(cm/s)[train_speed](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
            o = o + 2
            t:add(pf.train_spare, buf(o, 10)):set_text("预留[train_spare](10bytes),字节序(" .. (o-off) .. "):0x" .. buf(o,10))
            o = o + 10
        end
    end
    return o
end

-- 0x03 计划信息 (两项目格式相同)
local function parse_03(buf, off, tree)
    tree:add(pf.plat_count, buf(off + 2, 2)):set_text(
        "1.站台数[plat_count](2bytes),字节序(2):" .. buf(off + 2, 2):le_uint())
    local plat_num = buf(off + 2, 2):le_uint()
    local o = off + 4
    for i = 1, plat_num do
        local plat_start = o
        local rel = o - off
        local pt = tree:add(buf(o, buf:len() - o), "站台:" .. i .. ",字节序(" .. rel .. ")")

        pt:add(pf.station_id, buf(o, 2)):set_text("车站编号[station_id](2bytes),字节序(" .. rel .. "):" .. buf(o,2):le_uint())
        o = o + 2
        local pid = buf(o, 1):le_uint()
        pt:add(pf.platform_id, buf(o, 1)):set_text("站台编号[platform_id](1bytes),字节序(" .. (o-off) .. "):" .. pid)
        o = o + 1
        pt:add(pf.platform_train_count, buf(o, 2)):set_text("站台列车趟数[platform_train_count](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        local tnum = buf(o, 2):le_uint()
        o = o + 2

        for j = 1, tnum do
            local gl2, gstr2, o2 = read_varstr(buf, o)
            local ll2, lstr2, o3 = read_varstr(buf, o2)
            local train_fixed = 19
            local tlen = 1 + gl2 + 1 + ll2 + train_fixed
            local tr = pt:add(buf(o, tlen), "列车计划:" .. j .. ",字节序(" .. (o-off) .. ")")

            tr:add(pf.train_group_len, buf(o, 1)):set_text("车组号长度[train_group_len](1bytes),字节序(" .. (o-off) .. "):" .. gl2)
            o = o + 1
            tr:add(pf.train_group, buf(o, gl2)):set_text("车组号[train_group](" .. gl2 .. "bytes),字节序(" .. (o-off) .. "):" .. gstr2)
            o = o + gl2
            tr:add(pf.train_label_len, buf(o, 1)):set_text("车次号长度[train_label_len](1bytes),字节序(" .. (o-off) .. "):" .. ll2)
            o = o + 1
            tr:add(pf.train_label, buf(o, ll2)):set_text("车次号[train_label](" .. ll2 .. "bytes),字节序(" .. (o-off) .. "):" .. lstr2)
            o = o + ll2

            local st = buf(o, 1):le_uint()
            tr:add(pf.stop_train_type, buf(o, 1)):set_text("停车类型[stop_train_type](1bytes),字节序(" .. (o-off) .. "):" .. st .. desc(st, enum_stop))
            o = o + 1
            tr:add(pf.plan_arrive_time, buf(o, 7)):set_text("计划到站时间[plan_arrive_time](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
            o = o + 7
            tr:add(pf.plan_depart_time, buf(o, 7)):set_text("计划离站时间[plan_depart_time](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
            o = o + 7
            tr:add(pf.dest_id, buf(o, 2)):set_text("终到站[dest_id](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
            o = o + 2
            local cs = buf(o, 1):le_uint()
            tr:add(pf.current_status, buf(o, 1)):set_text("当前状态[current_status](1bytes),字节序(" .. (o-off) .. "):" .. cs .. desc(cs, enum_pstatus))
            o = o + 1
            local ht = buf(o, 1):le_uint()
            tr:add(pf.hold_train, buf(o, 1)):set_text("是否扣车[hold_train](1bytes),字节序(" .. (o-off) .. "):" .. ht .. desc(ht, enum_hold))
            o = o + 1
            tr:add(pf.spare_1, buf(o, 1)):set_text("预留1[spare_1](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint())
            o = o + 1
            local ft = buf(o, 1):le_uint()
            tr:add(pf.fast_train_flag, buf(o, 1)):set_text("大站快车标志[fast_train_flag](1bytes),字节序(" .. (o-off) .. "):" .. ft .. desc(ft, enum_fast))
            o = o + 1
            tr:add(pf.next_stop_id, buf(o, 2)):set_text("下一停车站站码[next_stop_id](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
            o = o + 2
            local cl = buf(o, 1):le_uint()
            tr:add(pf.clear_flag, buf(o, 1)):set_text("清客标志[clear_flag](1bytes),字节序(" .. (o-off) .. "):" .. cl .. desc(cl, enum_clear))
            o = o + 1
            tr:add(pf.spare_2, buf(o, 1)):set_text("预留2[spare_2](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint())
            o = o + 1
        end
        -- 修正站台节点长度
        pt:set_len(o - plat_start)
    end
    return o
end

-- 0x04 首末班信息
local function parse_04(buf, off, tree)
    tree:add(pf.plat_count, buf(off + 2, 2)):set_text(
        "1.站台数[plat_count](2bytes),字节序(2):" .. buf(off + 2, 2):le_uint())
    local plat_num = buf(off + 2, 2):le_uint()
    local o = off + 4
    for i = 1, plat_num do
        local plat_start = o
        local rel = o - off

        local pt = tree:add(buf(o, buf:len() - o), "站台:" .. i .. ",字节序(" .. rel .. ")")

        pt:add(pf.station_id, buf(o, 2)):set_text("车站编号[station_id](2bytes),字节序(" .. rel .. "):" .. buf(o,2):le_uint())
        o = o + 2
        pt:add(pf.platform_id, buf(o, 1)):set_text("站台编号[platform_id](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint())
        o = o + 1

        -- 首班
        local fgl2, fgstr, o2 = read_varstr(buf, o)
        pt:add(pf.first_group_len, buf(o, 1)):set_text("首班车组号长度[first_group_len](1bytes),字节序(" .. (o-off) .. "):" .. fgl2)
        o = o + 1
        pt:add(pf.first_group, buf(o, fgl2)):set_text("首班车组号[first_group](" .. fgl2 .. "bytes),字节序(" .. (o-off) .. "):" .. fgstr)
        o = o + fgl2
        local fll2, flstr, o3 = read_varstr(buf, o)
        pt:add(pf.first_label_len, buf(o, 1)):set_text("首班车次号长度[first_label_len](1bytes),字节序(" .. (o-off) .. "):" .. fll2)
        o = o + 1
        pt:add(pf.first_label, buf(o, fll2)):set_text("首班车次号[first_label](" .. fll2 .. "bytes),字节序(" .. (o-off) .. "):" .. flstr)
        o = o + fll2
        local fst = buf(o, 1):le_uint()
        pt:add(pf.first_stop_type, buf(o, 1)):set_text("首班停车类型[first_stop_type](1bytes),字节序(" .. (o-off) .. "):" .. fst .. desc(fst, enum_first_stop))
        o = o + 1
        pt:add(pf.first_arrive, buf(o, 7)):set_text("首班计划到站时间[first_arrive](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        pt:add(pf.first_depart, buf(o, 7)):set_text("首班计划离站时间[first_depart](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        pt:add(pf.first_dest, buf(o, 2)):set_text("首班终到站[first_dest](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2

        -- 末班
        local lgl2, lgstr, o4 = read_varstr(buf, o)
        pt:add(pf.last_group_len, buf(o, 1)):set_text("末班车组号长度[last_group_len](1bytes),字节序(" .. (o-off) .. "):" .. lgl2)
        o = o + 1
        pt:add(pf.last_group, buf(o, lgl2)):set_text("末班车组号[last_group](" .. lgl2 .. "bytes),字节序(" .. (o-off) .. "):" .. lgstr)
        o = o + lgl2
        local lll2, llstr, o5 = read_varstr(buf, o)
        pt:add(pf.last_label_len, buf(o, 1)):set_text("末班车次号长度[last_label_len](1bytes),字节序(" .. (o-off) .. "):" .. lll2)
        o = o + 1
        pt:add(pf.last_label, buf(o, lll2)):set_text("末班车次号[last_label](" .. lll2 .. "bytes),字节序(" .. (o-off) .. "):" .. llstr)
        o = o + lll2
        local lst = buf(o, 1):le_uint()
        pt:add(pf.last_stop_type, buf(o, 1)):set_text("末班停车类型[last_stop_type](1bytes),字节序(" .. (o-off) .. "):" .. lst .. desc(lst, enum_first_stop))
        o = o + 1
        pt:add(pf.last_arrive, buf(o, 7)):set_text("末班计划到站时间[last_arrive](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        pt:add(pf.last_depart, buf(o, 7)):set_text("末班计划离站时间[last_depart](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        pt:add(pf.last_dest, buf(o, 2)):set_text("末班终到站[last_dest](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2

        pt:set_len(o - plat_start)
    end
    return o
end

-- 0x05 车门隔离状态信息 (单条，无count)
-- 注: 0x05/0x06 字节序为高字节在前(大端), 参见文档"此部分信息字节序为高字节在前"
local function parse_05(buf, off, tree)
    local o = off + 2
    local rel = o - off
    tree:add(pf.psd_plat_id, buf(o, 4)):set_text("1.站台(股道)ID[psd_plat_id](4bytes),字节序(" .. rel .. "):" .. buf(o,4):uint())
    o = o + 4
    tree:add(pf.nid_psd_1, buf(o, 4)):set_text("2.1侧站台门ID[nid_psd_1](4bytes),字节序(" .. (o-off) .. "):" .. buf(o,4):uint())
    o = o + 4
    tree:add(pf.psd_1_isolation, buf(o, 8)):set_text("3.1侧故障隔离要求[psd_1_isolation](8bytes),字节序(" .. (o-off) .. "):0x" .. buf(o,8))
    o = o + 8
    tree:add(pf.nid_psd_2, buf(o, 4)):set_text("4.2侧站台门ID[nid_psd_2](4bytes),字节序(" .. (o-off) .. "):" .. buf(o,4):uint())
    o = o + 4
    tree:add(pf.psd_2_isolation, buf(o, 8)):set_text("5.2侧故障隔离要求[psd_2_isolation](8bytes),字节序(" .. (o-off) .. "):0x" .. buf(o,8))
    o = o + 8
    return o
end

-- 0x06 站台门隔离状态信息 (同0x05, 字节序为大端)
local function parse_06(buf, off, tree)
    local o = off + 2
    local count = buf(o, 1):le_uint()
    tree:add(pf.plat_count, buf(o, 1)):set_text("1.站台个数[plat_count](1bytes),字节序(2):" .. count)
    o = o + 1
    for i = 1, count do
        local plat_start = o
        local pt = tree:add(buf(o, 44), "站台:" .. i .. ",字节序(" .. (o-off) .. ")")
        pt:add(pf.psd_plat_id, buf(o, 4)):set_text("站台(股道)ID[psd_plat_id](4bytes),字节序(" .. (o-off) .. "):" .. buf(o,4):uint())
        o = o + 4
        pt:add(pf.nid_psd_1, buf(o, 4)):set_text("1侧站台门ID[nid_psd_1](4bytes),字节序(" .. (o-off) .. "):" .. buf(o,4):uint())
        o = o + 4
        pt:add(pf.psd_1_isolation, buf(o, 8)):set_text("1侧故障隔离要求[psd_1_isolation](8bytes),字节序(" .. (o-off) .. "):0x" .. buf(o,8))
        o = o + 8
        pt:add(pf.psd_1_open, buf(o, 8)):set_text("1侧站台门打开状态[psd_1_open](8bytes),字节序(" .. (o-off) .. "):0x" .. buf(o,8))
        o = o + 8
        pt:add(pf.nid_psd_2, buf(o, 4)):set_text("2侧站台门ID[nid_psd_2](4bytes),字节序(" .. (o-off) .. "):" .. buf(o,4):uint())
        o = o + 4
        pt:add(pf.psd_2_isolation, buf(o, 8)):set_text("2侧故障隔离要求[psd_2_isolation](8bytes),字节序(" .. (o-off) .. "):0x" .. buf(o,8))
        o = o + 8
        pt:add(pf.psd_2_open, buf(o, 8)):set_text("2侧站台门打开状态[psd_2_open](8bytes),字节序(" .. (o-off) .. "):0x" .. buf(o,8))
        o = o + 8
        pt:set_len(o - plat_start)
    end
    return o
end

-- 0x07 站场表示信息
local function parse_07(buf, off, tree)
    local o = off + 2
    local rtu = buf(o, 1):le_uint()
    tree:add(pf.rtu_status, buf(o, 1)):set_text("1.RTU状态[rtu_status](1bytes),字节序(2):" .. rtu .. desc(rtu, enum_bool))
    o = o + 1
    local sc = buf(o, 1):le_uint()
    tree:add(pf.station_count, buf(o, 1)):set_text("2.车站信息个数[station_count](1bytes),字节序(3):" .. sc)
    o = o + 1
    for i = 1, sc do
        local st_start = o
        local st = tree:add(buf(o, 6), "车站:" .. i)
        local sid = buf(o, 4):le_uint()
        st:add(pf.station_code, buf(o, 4)):set_text("3.站码[station_code](4bytes),字节序(" .. (o-off) .. "):" .. sid)
        o = o + 4
        local ylen = buf(o, 2):le_uint()
        st:add(pf.yard_data_len, buf(o, 2)):set_text("4.站场表示信息长[yard_data_len](2bytes),字节序(" .. (o-off) .. "):" .. ylen)
        o = o + 2

        local j = 0
        local idx = 1
        while j < ylen do
            local dev_start = o
            local dtype = buf(o, 1):le_uint()
            local dtype_name = "未知类型"
            if dtype == 0x11 then dtype_name = "逻辑区段"
            elseif dtype == 0x14 then dtype_name = "道岔"
            elseif dtype == 0x21 then dtype_name = "信号机"
            elseif dtype == 0x52 then dtype_name = "ESB按钮"
            elseif dtype == 0x62 then dtype_name = "防淹门"
            elseif dtype == 0x63 then dtype_name = "SPKS状态灯"
            elseif dtype == 0x64 then dtype_name = "SPKS旁路按钮"
            end
            st:add(pf.device_type, buf(o, 1)):set_text("5.设备类型[device_type](1bytes),字节序(" .. (o-off) .. "):0x" .. string.format("%02X", dtype) .. " " .. dtype_name)
            o = o + 1
            local did = buf(o, 4):le_uint()
            st:add(pf.device_id, buf(o, 4)):set_text("6.设备编号[device_id](4bytes),字节序(" .. (o-off) .. "):" .. did)
            o = o + 4
            local slen = buf(o, 1):le_uint()
            st:add(pf.sema_len, buf(o, 1)):set_text("7.色码长度[sema_len](1bytes),字节序(" .. (o-off) .. "):" .. slen)
            o = o + 1
            st:add(pf.sema_code, buf(o, slen)):set_text("8.色码[sema_code](" .. slen .. "bytes),字节序(" .. (o-off) .. "):0x" .. buf(o, slen))

            -- 色码详细解析
            if dtype == 0x11 then
                local b1 = buf(o, slen):bitfield(1,1)
                local b2 = buf(o, slen):bitfield(2,1)
                local b3 = buf(o, slen):bitfield(3,1)
                local b4 = buf(o, slen):bitfield(4,1)
                local b5 = buf(o, slen):bitfield(5,1)
                local b6 = buf(o, slen):bitfield(6,1)
                local b7 = buf(o, slen):bitfield(7,1)
                local b10 = buf(o, slen):bitfield(10,1)
                local b23 = buf(o, slen):bitfield(23,1)
                st:add(pf.sema_code, buf(o, slen)):set_text("   色码详细: 非通信列车占用:"..b1.." 锁闭:"..b2.." 故障锁闭:"..b3.." 封锁:"..b4.." CBTC占用:"..b5.." 保护区段锁闭:"..b6.." 区段切除:"..b7.." 计轴复位:"..b10.." ARB故障:"..b23)
            elseif dtype == 0x14 then
                local b1 = buf(o, slen):bitfield(1,1)
                local b2 = buf(o, slen):bitfield(2,1)
                local b3 = buf(o, slen):bitfield(3,1)
                local b45 = buf(o, slen):bitfield(4,2)
                local b6 = buf(o, slen):bitfield(6,1)
                local b7 = buf(o, slen):bitfield(7,1)
                local b8 = buf(o, slen):bitfield(8,1)
                local b9 = buf(o, slen):bitfield(9,1)
                local b10 = buf(o, slen):bitfield(10,1)
                local b11 = buf(o, slen):bitfield(11,1)
                local b30 = buf(o, slen):bitfield(30,1)
                st:add(pf.sema_code, buf(o, slen)):set_text("   色码详细: 非通信列车占用:"..b1.." 锁闭:"..b2.." 故障锁闭:"..b3.." 道岔位置:"..b45.." 单锁:"..b6.." 单封:"..b7.." CBTC占用:"..b8.." 保护区段锁闭:"..b9.." 轨道切除:"..b10.." 区段封锁:"..b11.." ARB故障:"..b30)
            elseif dtype == 0x21 then
                local b14 = buf(o, slen):bitfield(1,4)
                local b5 = buf(o, slen):bitfield(5,1)
                local b69 = buf(o, slen):bitfield(6,4)
                local b10 = buf(o, slen):bitfield(10,1)
                local b12 = buf(o, slen):bitfield(12,1)
                local b14f = buf(o, slen):bitfield(14,1)
                st:add(pf.sema_code, buf(o, slen)):set_text("   色码详细: 低位颜色:"..b14.." 低位闪烁:"..b5.." 高位颜色:"..b69.." 高位闪烁:"..b10.." CBTC灭灯:"..b12.." 屏蔽一次临限:"..b14f)
            elseif dtype == 0x52 then
                local b1 = buf(o, slen):bitfield(1,1)
                st:add(pf.sema_code, buf(o, slen)):set_text("   色码详细: 站台紧急关闭:"..b1)
            elseif dtype == 0x62 then
                local b1 = buf(o, slen):bitfield(1,1)
                local b2 = buf(o, slen):bitfield(2,1)
                local b3 = buf(o, slen):bitfield(3,1)
                st:add(pf.sema_code, buf(o, slen)):set_text("   色码详细: 门关开状态:"..b1.." 关门请求:"..b2.." 关门允许:"..b3)
            elseif dtype == 0x63 then
                local b1 = buf(o, slen):bitfield(1,1)
                st:add(pf.sema_code, buf(o, slen)):set_text("   色码详细: SPKS状态灯:"..b1)
            elseif dtype == 0x64 then
                local b1 = buf(o, slen):bitfield(1,1)
                st:add(pf.sema_code, buf(o, slen)):set_text("   色码详细: SPKS旁路按钮:"..b1)
            end

            o = o + slen
            j = j + 6 + slen
            idx = idx + 1
        end
        st:set_len(o - st_start)
    end
    return o
end

-- 0x08 供电臂/供电分区信息
local function parse_08(buf, off, tree)
    tree:add(pf.power_count, buf(off + 2, 2)):set_text(
        "1.供电区段数目[power_count](2bytes),字节序(2):" .. buf(off + 2, 2):le_uint())
    local num = buf(off + 2, 2):le_uint()
    local o = off + 4
    for i = 1, num do
        local pt = tree:add(buf(o, 3), "区段:" .. i .. ",字节序(" .. (o-off) .. ")")
        pt:add(pf.power_section_id, buf(o, 2)):set_text("供电区段编号[power_section_id](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2
        local st = buf(o, 1):le_uint()
        pt:add(pf.power_status, buf(o, 1)):set_text("供电区段状态[power_status](1bytes),字节序(" .. (o-off) .. "):" .. st .. desc(st, enum_power))
        o = o + 1
    end
    return o
end

-- 0x09 首末班申请 (4字节固定 0x00000000)
local function parse_09(buf, off, tree)
    tree:add(pf.firstlast_request, buf(off + 2, 4)):set_text(
        "1.首末班申请[firstlast_request](4bytes),字节序(2):0x" .. buf(off + 2, 4) .. " | 固定0x00000000")
    return off + 6
end

-- 0x10 场段出入段计划信息 (仅GZL10)
local function parse_10(buf, off, tree)
    local o = off + 2
    tree:add(pf.schedule_date, buf(o, 7)):set_text("1.调度日[schedule_date](7bytes),字节序(2):" .. fmt_time7(buf, o))
    o = o + 7
    local dnl, dstr, o2 = read_varstr(buf, o)
    tree:add(pf.drawing_no_len, buf(o, 1)):set_text("2.图号长度[drawing_no_len](1bytes),字节序(" .. (o-off) .. "):" .. dnl)
    o = o + 1
    tree:add(pf.drawing_no, buf(o, dnl)):set_text("3.图号[drawing_no](" .. dnl .. "bytes),字节序(" .. (o-off) .. "):" .. dstr)
    o = o + dnl
    tree:add(pf.depot_station_code, buf(o, 2)):set_text("4.段/场站码[depot_station_code](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
    o = o + 2
    local sg = buf(o, 1):le_uint()
    tree:add(pf.service_group_count, buf(o, 1)):set_text("5.服务号组数[service_group_count](1bytes),字节序(" .. (o-off) .. "):" .. sg)
    o = o + 1

    for i = 1, sg do
        local grp_start = o
        local snl, sstr, o2 = read_varstr(buf, o)
        local grp = tree:add(buf(o, buf:len() - o), "组:" .. i .. ",字节序(" .. (o-off) .. ")")

        grp:add(pf.service_no_len, buf(o, 1)):set_text("6.服务号长度[service_no_len](1bytes),字节序(" .. (o-off) .. "):" .. snl)
        o = o + 1
        grp:add(pf.service_no, buf(o, snl)):set_text("7.服务号[service_no](" .. snl .. "bytes),字节序(" .. (o-off) .. "):" .. sstr)
        o = o + snl
        grp:add(pf.out_depot_code, buf(o, 2)):set_text("8.出段/场站码[out_depot_code](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2

        local otl, otstr, o3 = read_varstr(buf, o)
        grp:add(pf.out_train_label_len, buf(o, 1)):set_text("9.出段/场车次号长度[out_train_label_len](1bytes),字节序(" .. (o-off) .. "):" .. otl)
        o = o + 1
        grp:add(pf.out_train_label, buf(o, otl)):set_text("10.出段/场车次号[out_train_label](" .. otl .. "bytes),字节序(" .. (o-off) .. "):" .. otstr)
        o = o + otl
        local ogl, ogstr, o4 = read_varstr(buf, o)
        grp:add(pf.out_train_group_len, buf(o, 1)):set_text("11.出段/场车组号长度[out_train_group_len](1bytes),字节序(" .. (o-off) .. "):" .. ogl)
        o = o + 1
        grp:add(pf.out_train_group, buf(o, ogl)):set_text("12.出段/场车组号[out_train_group](" .. ogl .. "bytes),字节序(" .. (o-off) .. "):" .. ogstr)
        o = o + ogl
        local dtl, dtstr, o5 = read_varstr(buf, o)
        grp:add(pf.departure_track_len, buf(o, 1)):set_text("13.段/场内出发股道名称长度[departure_track_len](1bytes),字节序(" .. (o-off) .. "):" .. dtl)
        o = o + 1
        grp:add(pf.departure_track, buf(o, dtl)):set_text("14.段/场内出发股道名称[departure_track](" .. dtl .. "bytes),字节序(" .. (o-off) .. "):" .. dtstr)
        o = o + dtl
        grp:add(pf.planned_departure, buf(o, 7)):set_text("15.段/场内计划出发时间[planned_departure](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.actual_departure, buf(o, 7)):set_text("16.段/场内出发时间[actual_departure](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.departure_mark, buf(o, 1)):set_text("17.段/场内报点标志[departure_mark](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint())
        o = o + 1
        local trl, trstr, o6 = read_varstr(buf, o)
        grp:add(pf.transfer_rail_out_len, buf(o, 1)):set_text("18.出段/场转换轨名称长度[transfer_rail_out_len](1bytes),字节序(" .. (o-off) .. "):" .. trl)
        o = o + 1
        grp:add(pf.transfer_rail_out, buf(o, trl)):set_text("19.出段/场转换轨名称[transfer_rail_out](" .. trl .. "bytes),字节序(" .. (o-off) .. "):" .. trstr)
        o = o + trl
        grp:add(pf.transfer_arr_plan, buf(o, 7)):set_text("20.出段/场转换轨计划到达时间[transfer_arr_plan](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.transfer_arr_actual, buf(o, 7)):set_text("21.出段/场转换轨到达时间[transfer_arr_actual](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.transfer_dep_plan, buf(o, 7)):set_text("22.出段/场转换轨计划出发时间[transfer_dep_plan](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.transfer_dep_actual, buf(o, 7)):set_text("23.出段/场转换轨出发时间[transfer_dep_actual](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.transfer_mark_out, buf(o, 1)):set_text("24.出段/场转换轨报点标志[transfer_mark_out](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint())
        o = o + 1
        grp:add(pf.mainline_code_out, buf(o, 2)):set_text("25.出段/场正线站码[mainline_code_out](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2
        grp:add(pf.mainline_arrival_out, buf(o, 7)):set_text("26.出段/场正线到达时间[mainline_arrival_out](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.destination_code_out, buf(o, 4)):set_text("27.出段/场目的地码[destination_code_out](4bytes),字节序(" .. (o-off) .. "):" .. buf(o,4):string())
        o = o + 4

        grp:add(pf.in_depot_code, buf(o, 2)):set_text("28.入段/场车辆段站码[in_depot_code](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2
        local itl, itstr, o7 = read_varstr(buf, o)
        grp:add(pf.in_train_label_len, buf(o, 1)):set_text("29.入段/场车次号长度[in_train_label_len](1bytes),字节序(" .. (o-off) .. "):" .. itl)
        o = o + 1
        grp:add(pf.in_train_label, buf(o, itl)):set_text("30.入段/场车次号[in_train_label](" .. itl .. "bytes),字节序(" .. (o-off) .. "):" .. itstr)
        o = o + itl
        local igl, igstr, o8 = read_varstr(buf, o)
        grp:add(pf.in_train_group_len, buf(o, 1)):set_text("31.入段/场车组号长度[in_train_group_len](1bytes),字节序(" .. (o-off) .. "):" .. igl)
        o = o + 1
        grp:add(pf.in_train_group, buf(o, igl)):set_text("32.入段/场车组号[in_train_group](" .. igl .. "bytes),字节序(" .. (o-off) .. "):" .. igstr)
        o = o + igl
        local atl, atstr, o9 = read_varstr(buf, o)
        grp:add(pf.arrival_track_len, buf(o, 1)):set_text("33.段/场内到达股道名称长度[arrival_track_len](1bytes),字节序(" .. (o-off) .. "):" .. atl)
        o = o + 1
        grp:add(pf.arrival_track, buf(o, atl)):set_text("34.段/场内到达股道名称[arrival_track](" .. atl .. "bytes),字节序(" .. (o-off) .. "):" .. atstr)
        o = o + atl
        grp:add(pf.planned_arrival, buf(o, 7)):set_text("35.段/场内计划到达时间[planned_arrival](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.actual_arrival, buf(o, 7)):set_text("36.段/场内到达时间[actual_arrival](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.arrival_mark, buf(o, 1)):set_text("37.段/场内报点标志[arrival_mark](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint())
        o = o + 1
        local tril, tristr, o10 = read_varstr(buf, o)
        grp:add(pf.transfer_rail_in_len, buf(o, 1)):set_text("38.入段/场转换轨名称长度[transfer_rail_in_len](1bytes),字节序(" .. (o-off) .. "):" .. tril)
        o = o + 1
        grp:add(pf.transfer_rail_in, buf(o, tril)):set_text("39.入段/场转换轨名称[transfer_rail_in](" .. tril .. "bytes),字节序(" .. (o-off) .. "):" .. tristr)
        o = o + tril
        grp:add(pf.in_transfer_arr_plan, buf(o, 7)):set_text("40.入段/场转换轨计划到达时间[in_transfer_arr_plan](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.in_transfer_arr_actual, buf(o, 7)):set_text("41.入段/场转换轨到达时间[in_transfer_arr_actual](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.in_transfer_dep_plan, buf(o, 7)):set_text("42.入段/场转换轨计划出发时间[in_transfer_dep_plan](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.in_transfer_dep_actual, buf(o, 7)):set_text("43.入段/场转换轨出发时间[in_transfer_dep_actual](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.transfer_mark_in, buf(o, 1)):set_text("44.入段/场转换轨报点标志[transfer_mark_in](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint())
        o = o + 1
        grp:add(pf.mainline_code_in, buf(o, 2)):set_text("45.入段/场正线站码[mainline_code_in](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2
        grp:add(pf.mainline_arrival_in, buf(o, 7)):set_text("46.入段/场正线到达时间[mainline_arrival_in](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.destination_code_in, buf(o, 4)):set_text("47.入段/场目的地码[destination_code_in](4bytes),字节序(" .. (o-off) .. "):" .. buf(o,4):string())
        o = o + 4

        grp:add(pf.is_initial, buf(o, 1)):set_text("48.是否是初始化生成[is_initial](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint() .. desc(buf(o,1):le_uint(), enum_bool))
        o = o + 1
        grp:add(pf.initial_time, buf(o, 7)):set_text("49.初始化时间[initial_time](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.is_wash, buf(o, 1)):set_text("50.是否回段洗车[is_wash](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint() .. desc(buf(o,1):le_uint(), enum_bool))
        o = o + 1
        grp:add(pf.spare_plan, buf(o, 2)):set_text("51.预留[spare_plan](2bytes),字节序(" .. (o-off) .. "):0x" .. buf(o,2))
        o = o + 2
        grp:add(pf.is_auto_wake, buf(o, 1)):set_text("52.是否自动唤醒[is_auto_wake](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint() .. desc(buf(o,1):le_uint(), enum_bool))
        o = o + 1
        grp:add(pf.wakeup_time, buf(o, 7)):set_text("53.计划唤醒时间[wakeup_time](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.is_clean, buf(o, 1)):set_text("54.是否回库清扫[is_clean](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint() .. desc(buf(o,1):le_uint(), enum_bool))
        o = o + 1
        grp:add(pf.clean_start, buf(o, 7)):set_text("55.清扫开始时间[clean_start](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.clean_end, buf(o, 7)):set_text("56.清扫结束时间[clean_end](7bytes),字节序(" .. (o-off) .. "):" .. fmt_time7(buf, o))
        o = o + 7
        grp:add(pf.is_auto_sleep, buf(o, 1)):set_text("57.是否自动休眠[is_auto_sleep](1bytes),字节序(" .. (o-off) .. "):" .. buf(o,1):le_uint() .. desc(buf(o,1):le_uint(), enum_bool))
        o = o + 1
        grp:add(pf.spare_plan2, buf(o, 10)):set_text("58.预留2[spare_plan2](10bytes),字节序(" .. (o-off) .. "):0x" .. buf(o,10))
        o = o + 10

        grp:set_len(o - grp_start)
    end
    return o
end

-- 0x11 车站火灾信息 (GZL10)
local function parse_11(buf, off, tree)
    tree:add(pf.fire_station_count, buf(off + 2, 2)):set_text(
        "1.车站数目[fire_station_count](2bytes),字节序(2):" .. buf(off + 2, 2):le_uint())
    local num = buf(off + 2, 2):le_uint()
    local o = off + 4
    for i = 1, num do
        local pt = tree:add(buf(o, 3), "车站:" .. i .. ",字节序(" .. (o-off) .. ")")
        pt:add(pf.fire_station_id, buf(o, 2)):set_text("车站编号[fire_station_id](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2
        local st = buf(o, 1):le_uint()
        pt:add(pf.fire_station_status, buf(o, 1)):set_text("车站火灾状态[fire_station_status](1bytes),字节序(" .. (o-off) .. "):" .. st .. desc(st, enum_fire))
        o = o + 1
    end
    return o
end

-- 0x12 区间火灾信息 (GZL10)
local function parse_12(buf, off, tree)
    tree:add(pf.zone_fire_count, buf(off + 2, 2)):set_text(
        "1.区间数目[zone_fire_count](2bytes),字节序(2):" .. buf(off + 2, 2):le_uint())
    local num = buf(off + 2, 2):le_uint()
    local o = off + 4
    for i = 1, num do
        local pt = tree:add(buf(o, 3), "区间:" .. i .. ",字节序(" .. (o-off) .. ")")
        pt:add(pf.zone_fire_id, buf(o, 2)):set_text("区间编号[zone_fire_id](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2
        local st = buf(o, 1):le_uint()
        pt:add(pf.zone_fire_status, buf(o, 1)):set_text("区间火灾状态[zone_fire_status](1bytes),字节序(" .. (o-off) .. "):" .. st .. desc(st, enum_zone_fire))
        o = o + 1
    end
    return o
end

-- 0x13 区间轨面水位告警信息 (GZL10)
local function parse_13(buf, off, tree)
    tree:add(pf.water_count, buf(off + 2, 2)):set_text(
        "1.轨面水位传感器数目[water_count](2bytes),字节序(2):" .. buf(off + 2, 2):le_uint())
    local num = buf(off + 2, 2):le_uint()
    local o = off + 4
    for i = 1, num do
        local pt = tree:add(buf(o, 3), "传感器:" .. i .. ",字节序(" .. (o-off) .. ")")
        pt:add(pf.water_sensor_id, buf(o, 2)):set_text("轨面水位传感器编号[water_sensor_id](2bytes),字节序(" .. (o-off) .. "):" .. buf(o,2):le_uint())
        o = o + 2
        local st = buf(o, 1):le_uint()
        pt:add(pf.water_status, buf(o, 1)):set_text("轨面水位告警标志[water_status](1bytes),字节序(" .. (o-off) .. "):" .. st .. desc(st, enum_water))
        o = o + 1
    end
    return o
end

-- ============================================
-- 消息分发表
-- ============================================
local dissect_body = {
    [1]  = parse_01,
    [2]  = parse_02,
    [3]  = parse_03,
    [4]  = parse_04,
    [5]  = parse_05,
    [6]  = parse_06,
    [7]  = parse_07,
    [8]  = parse_08,
    [9]  = parse_09,
    [16] = parse_10,
    [17] = parse_11,
    [18] = parse_12,
    [19] = parse_13,
}

-- ============================================
-- 主解析流程
-- ============================================

local tmp_buf = ByteArray.new()

local function full_packet_dissactor(buffer, pinfo, tree)
    local b_offset = pinfo.desegment_offset or 0
    local buf_len = buffer:len()
    if buf_len < 9 then return -1 end

    while b_offset < buf_len do
        local rsic_data_len = buffer(b_offset + 4, 2):le_uint()
        local rsic_total = buffer(b_offset + 2, 1):le_uint()
        local rsic_index = buffer(b_offset + 3, 1):le_uint()
        local total_len = 9 + rsic_data_len

        if b_offset + total_len > buf_len then
            pinfo.desegment_len = b_offset + total_len - buf_len
            pinfo.desegment_offset = b_offset
            return 0
        end

        pinfo.cols.protocol = rsic_protocol.name
        local subtree = tree:add(rsic_protocol, buffer(b_offset, total_len),
                                 "RSIC Protocol Data, Len: " .. total_len)

        -- 头部
        local headerTree = subtree:add(buffer(b_offset, 7), "Header")
        headerTree:add_le(pf.data_head, buffer(b_offset, 2))
        headerTree:add(pf.total, buffer(b_offset + 2, 1))
        headerTree:add(pf.index, buffer(b_offset + 3, 1))
        headerTree:add_le(pf.data_len, buffer(b_offset + 4, 2))
        local dev_st = buffer(b_offset + 6, 1):le_uint()
        headerTree:add(pf.dev_status, buffer(b_offset + 6, 1)):append_text(
            " (" .. (enum_ha[dev_st] or dev_st) .. ")")

        -- 帧尾
        local tailTree = subtree:add(buffer(b_offset + total_len - 2, 2), "Tail")
        tailTree:add_le(pf.data_tail, buffer(b_offset + total_len - 2, 2))

        -- 分包重组
        if rsic_index == 1 then
            tmp_buf = ByteArray.new()
        end
        local byte_range = buffer:bytes(b_offset + 7, rsic_data_len)
        tmp_buf:append(byte_range)

        if rsic_total == rsic_index then
            local tvb = tmp_buf:tvb()
            local data_type_val = tvb(0, 2):le_uint()
            local type_name = dataTypeStr[data_type_val] or ("未知类型:" .. data_type_val)
            subtree:append_text(" , Type:0x" .. string.format("%02X", data_type_val) .. " " .. type_name)

            -- 项目选择
            local is_gzl10 = (prefs.my_line_project == 2)
            if is_gzl10 then
                subtree:append_text(" , 广州10&12号线")
            else
                subtree:append_text(" , 广州18&22&11号线")
            end

            -- 解析数据域
            local parse_fn = dissect_body[data_type_val]
            if parse_fn then
                -- 列车信息需要区分项目
                if data_type_val == 2 then
                    parse_fn(tvb, 0, subtree, is_gzl10)
                else
                    -- GZL18 不支持 0x10/0x11/0x12/0x13
                    if not is_gzl10 and (data_type_val == 16 or data_type_val == 17 or data_type_val == 18 or data_type_val == 19) then
                        subtree:add(tvb(0, tvb:len()), "Data: 该项目不支持此消息类型")
                    else
                        parse_fn(tvb, 0, subtree)
                    end
                end
            else
                subtree:add(tvb(0, tvb:len()), "Data: 未实现解析, Type:0x" .. string.format("%02X", data_type_val))
            end

            subtree:append_text(" , total:" .. rsic_total .. " ,all data len:" .. tmp_buf:len())
        elseif rsic_total > rsic_index then
            subtree:append_text(" , need total:" .. rsic_total .. " but index:" .. rsic_index .. " ,this len:" .. tmp_buf:len())
        else
            tmp_buf = ByteArray.new()
            subtree:append_text(" , wrong total:" .. rsic_total .. " and index:" .. rsic_index)
            return -1
        end

        b_offset = b_offset + total_len
        if b_offset == buf_len then return 1 end
    end
    return 1
end

function rsic_protocol.dissector(buffer, pinfo, tree)
    local ret = full_packet_dissactor(buffer, pinfo, tree)
    if ret == 1 then
        -- 完整包
    elseif ret == 0 then
        -- 不完整包，等待更多数据
    else
        data_dis:call(buffer, pinfo, tree)
    end
end

-- ============================================
-- 端口注册
-- ============================================
local function parse_ports(ports_str)
    local ports = {}
    for port in string.gmatch(ports_str, "%d+") do
        table.insert(ports, tonumber(port))
    end
    return ports
end

local tcp_port = DissectorTable.get("tcp.port")

local function add_port()
    if rsic_protocol.prefs.my_tcp_port ~= "" then
        local ports = parse_ports(rsic_protocol.prefs.my_tcp_port)
        for _, port in ipairs(ports) do
            tcp_port:add(port, rsic_protocol)
        end
    end
end

add_port()
function rsic_protocol.prefs_changed() add_port() end
